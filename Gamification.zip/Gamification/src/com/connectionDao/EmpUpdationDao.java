package com.connectionDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;

import com.bean.Employee;
import com.dbCon.DBConnection;

public class EmpUpdationDao {
	
			//private DataSource dataSource;

	public EmpUpdationDao() {
		super();
	}

			/*public EmpUpdationDao(DataSource dataSource) {
				super();
				this.dataSource = dataSource;
			}*/
	
	@SuppressWarnings("resource")
	public String updateEmployeeDetail(String bensyl_Id, Employee objEmp) throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		int result=0;
		String sql="", msg="";
		DBConnection dbCon=new DBConnection();
		
		try {
					//con=dataSource.getConnection();			
			//check whether bensil_id is updated or not
			
			if(!(bensyl_Id.equals(objEmp.getBensyl_id()))){				
				//check whether the updated bensyl_id is already belongs to someone.
				sql="select emp_name from game_employee where upper(bensyl_id)=?";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, objEmp.getBensyl_id());
				rs=pstmt.executeQuery();
				if(rs.next()){
					msg="exist";
				}
				else{
					//If new Bensyl_id is not belongs to anyone then update that employee details with updated details
					sql="update game_employee set bensyl_id=?,emp_name=?,emp_email=?,linemng_id=? where upper(bensyl_id)=?";
							//pstmt=con.prepareStatement(sql);
					pstmt=dbCon.getStatement(sql);
					pstmt.setString(1, objEmp.getBensyl_id());
					pstmt.setString(2, objEmp.getEmp_name());
					pstmt.setString(3, objEmp.getEmp_email());
					pstmt.setString(4, objEmp.getLinemng_id());
					pstmt.setString(5, bensyl_Id);
					result=pstmt.executeUpdate();
					if(result==1){
						msg="updated";
					}
					else{
						msg="failed";
					}					
				}
			}
			else{				
				//if bensyl_id is not changed update other details in that bensyl_id
				sql="update game_employee set emp_name=?,emp_email=?,linemng_id=? where upper(bensyl_id)=?";
						//pstmt=con.prepareStatement(sql);
				pstmt=dbCon.getStatement(sql);
				pstmt.setString(1, objEmp.getEmp_name());
				pstmt.setString(2, objEmp.getEmp_email());
				pstmt.setString(3, objEmp.getLinemng_id());
				pstmt.setString(4, bensyl_Id);
				result=pstmt.executeUpdate();
				if(result==1){
					msg="updated";
				}
				else{
					msg="failed";
				}				
			}			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {			
					//con.close();
			pstmt.close();
			if(rs!=null){
				rs.close();
			}
		}
		return msg;
	}

	
	public String deleteEmployeeDetail(String bensyl_Id) throws SQLException {
		
				//Connection con=null;
		PreparedStatement pstmt=null;
		int result=0;
		String sql="", msg="";
		DBConnection dbCon=new DBConnection();
		
		try {
			//update employee status to deleted so that he can't login any more.
			sql="update game_employee set status='deleted' where bensyl_id=?";
					/*con=dataSource.getConnection();
					pstmt=con.prepareStatement(sql);*/
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, bensyl_Id);
			result=pstmt.executeUpdate();
			if(result==1){
				msg="updated";
			}
			else{
				msg="failed";
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		finally {
					//con.close();
			pstmt.close();
		}		
		return msg;
	}
}
