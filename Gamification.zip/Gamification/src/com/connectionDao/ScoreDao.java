package com.connectionDao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Year;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import com.bean.Scores;
import com.dbCon.DBConnection;

public class ScoreDao {
	
			//private DataSource dataSource;

	public ScoreDao() {
		super();
	}

			/*public ScoreDao(DataSource dataSource) {
				super();
				this.dataSource = dataSource;
			}*/

	public List<Scores> getScoreBoard() {
		String sql="";
				//Connection con=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		List<Scores> scoreList=new ArrayList<Scores>();
		int count=1;
		DBConnection dbCon=new DBConnection();
		
		try {
					//con=dataSource.getConnection();
			int year=Year.now().getValue();
			String strYear=Integer.toString(year);
			sql="select e.bensyl_id,e.emp_name,s.hours,s.trn_level,s.badge,s.trophy "+
					"from game_employee e join game_scoreboard s on e.bensyl_id=s.bensyl_id "+
					"where s.trn_year=? order by s.hours desc";
					//pstmt=con.prepareStatement(sql);
			pstmt=dbCon.getStatement(sql);
			pstmt.setString(1, strYear);
			rs=pstmt.executeQuery();
			
			while(rs.next()){
				Scores objScore=new Scores();
				objScore.setCount(count);
				count++;
				objScore.setBensyl_id(rs.getString("bensyl_id"));
				objScore.setName(rs.getString("emp_name"));
				objScore.setHours(rs.getFloat("hours"));
				objScore.setTrn_level(rs.getInt("trn_level"));
				objScore.setBadge(rs.getInt("badge"));
				objScore.setTrophy(rs.getInt("trophy"));
				scoreList.add(objScore);				
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return scoreList;
	}
	
	
	
}
