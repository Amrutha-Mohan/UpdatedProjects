package com.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

import com.bean.Employee;
import com.bean.Manager;
import com.bean.Scores;
import com.connectionDao.EmployeeDao;
import com.connectionDao.ReportDao;

/**
 * Servlet implementation class ReportController
 */
@WebServlet("/ReportController")
public class ReportController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private ReportDao rptDao;
	private EmployeeDao empDao;	

			/*@Resource(name="gameDB")
			private DataSource dataSource;*/
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ReportController() {
        super();
    }
    
    @Override
	public void init() throws ServletException {
		super.init();
				/*rptDao=new ReportDao(dataSource);
				empDao=new EmployeeDao(dataSource);*/
		rptDao=new ReportDao();
		empDao=new EmployeeDao();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
		String cmd=request.getParameter("cmd");
		if(cmd.equals("manager")){
			getManagers(request,response);
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cmd=request.getParameter("cmd");
		if(cmd.equals("loadTrn")){
			loadTrainingDetail(request,response);
		}
		else if(cmd.equals("Download & Mail")){
			downloadTraining(request,response);
		}
		
	}

	private void downloadTraining(HttpServletRequest request, HttpServletResponse response) {

		String bensyl_id=request.getParameter("manager");
		List<Employee> mngList;
		int result=0;
		try {
			
			HttpSession session = request.getSession(false);
			String email=(String)session.getAttribute("uname");
			result=rptDao.downloadPDF(bensyl_id,email);
			mngList = empDao.getManagers();
			request.setAttribute("mngList",mngList);
			if(result==1){
				request.setAttribute("ErrDown","Downloaded");	
			}	
			RequestDispatcher dispatcher= request.getRequestDispatcher("admin_report.jsp");
			dispatcher.forward(request, response);
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	private void getManagers(HttpServletRequest request, HttpServletResponse response) {
		
		List<Employee> mngList;
		try {
			//Call method to get all manager IDs
			mngList = empDao.getManagers();
			request.setAttribute("mngList",mngList);
			RequestDispatcher dispatcher= request.getRequestDispatcher("admin_report.jsp");
			dispatcher.forward(request, response);
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ServletException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void loadTrainingDetail(HttpServletRequest request, HttpServletResponse response) {
		
		String mngId="";
		mngId=request.getParameter("id");
		try {
			List<Scores> listTrns=rptDao.getTrainingDetails(mngId);
			request.setAttribute("listTrns",listTrns);	
			RequestDispatcher dispatcher= request.getRequestDispatcher("admin_mng_training.jsp");
			dispatcher.forward(request, response);
		} catch (ServletException | IOException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
