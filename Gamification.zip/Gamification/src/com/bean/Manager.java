package com.bean;

public class Manager {
	private String bensyl_Id;

	public Manager() {
		super();
	}

	public Manager(String bensyl_Id) {
		super();
		this.bensyl_Id = bensyl_Id;
	}

	public String getBensyl_Id() {
		return bensyl_Id;
	}

	public void setBensyl_Id(String bensyl_Id) {
		this.bensyl_Id = bensyl_Id;
	}	
}
