package com.dbCon;

import java.io.*;
import java.sql.*;
import java.util.Properties;

public class DBConnection {

	public Connection getConn()
	{
		Connection con = null;
		Properties property = new Properties();
		InputStream input = null;

		try {
			input = new FileInputStream("/WebApplications/Gamification/config.properties");
			
			// load a properties file
			property.load(input);
			input.close();
			Class.forName(property.getProperty("ojdbc.driver")); //loading oracle drivers. This differs for database servers
			con = DriverManager.getConnection(property.getProperty("ojdbc.url"), property.getProperty("ojdbc.username"),property.getProperty("ojdbc.password")); //attempting to connect to oracle database
			System.out.println("Printing connection object "+con);
			
		} catch (IOException e1) {
			e1.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}



		return con; 
	}

}
