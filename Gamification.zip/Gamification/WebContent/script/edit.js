/**
 * 
 */

function loadEditForm1() {
	
	var RegExp1=/^(?=.*?[a-zA-Z])(?=.*?[0-9]).{6,7}$/;
	document.getElementById("empidMsg").innerHTML="";
	var xhttp = new XMLHttpRequest();
	var id=document.getElementById("empid").value;
	if(id==""){
		document.getElementById("empidMsg").innerHTML="ID Required";
		return false;
	}
	else if(!(id.match(RegExp1))){
		document.getElementById("empidMsg").innerHTML="Not a valid Bensyl or Staff ID";
		document.f4.empid.value="";
		return false;
	}
	else if(id != ""){
		xhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("edit").innerHTML =
					this.responseText;
			}
		};
		xhttp.open("GET", "EmployeeController?val="+id+"&cmd=searchEmp", true);
		xhttp.send();
	}
}

function loadTrainings() {
	var xhttp = new XMLHttpRequest();
	var mngId=document.getElementById("mngr").value;
	xhttp.onreadystatechange = function() {
		if (this.readyState == 4 && this.status == 200) {
			document.getElementById("training").innerHTML =
				this.responseText;
		}
	};
	xhttp.open("POST", "ReportController?id="+mngId+"&cmd=loadTrn", true);
	xhttp.send(); 
}
