    $(document).ready(function(){
    	$("#second").hide();
        $("#lgin").click(function(){
            $.ajax({
                url: 'http://localhost:8080/Gamification/Profile?id='+encodeURIComponent($("#loginusername").val()),
                dataType: 'json',
                success:function(response){
    				console.log(response.level);
    				$("#first").hide();
            		$("#second").show();

                    setTimeout(function() {
                    	if(response.level == 1){
                    		
                    		$("#carGif").addClass("carAnimate1");
                            setTimeout(function() {
                                $("#tbox1").fadeIn('300');
                                $("#tbox1").append("test");
                            }, 2100);
                        }
                        else if(response.level == 2){
                        	
                            $("#carGif").addClass("carAnimate2");
                            setTimeout(function() {
                                $("#tbox2").fadeIn('300');
                            }, 4100);
                        }
                        else if(response.level == 3){
                            $("#carGif").addClass("carAnimate3");
                            //$("#note3").slideLeft( "slow" );
                            setTimeout(function() {
                                $("#tbox3").fadeIn('300');
                            }, 5100);
                            /*$("#carGif").animate({
                                bottom: "52%",
                                left: "43%"
                            }, 5000, 'linear', function() {
                                // Animation complete.
                            });*/
                        }
                        else if(response.level == 4){
                            $("#carGif").addClass("carAnimate4");
                            setTimeout(function() {
                                $("#tbox4").fadeIn('300');
                            }, 7100);
                        }
                    }, 1000);
        
         }
            });
        });
});
    